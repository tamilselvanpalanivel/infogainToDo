import React from 'react';
import TableRendering from './components/TableRendering.js';
import InputController from './components/InputController.js';
import JsonData from './search-list.json';

class App extends React.Component{
  constructor(props){
       super(props);
       this.state = {
         storedData: JsonData
       }
       this.onSearchResult=this.onSearchResult.bind(this);
    }
    
    onSearchResult(searchVal){
      if(searchVal){
        let filterData = this.state.storedData.filter(function (e) {
            return e.name.toLowerCase().includes(searchVal.toLowerCase()) || e.gender.includes(searchVal);
        });
        
        this.setState({
          storedData:filterData
        });
      } else {
        this.setState({
          storedData:JsonData
        });
      }


    }

  render () {
    return(
      <div className="container">
        <InputController onSearch={this.onSearchResult} />
        <TableRendering dataVal={this.state.storedData} />
     </div>      
    );
  }
}

export default App;
