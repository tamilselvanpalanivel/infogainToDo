import React from "react";
import {BootstrapTable, TableHeaderColumn} from 'react-bootstrap-table';
import { Col } from 'react-bootstrap';

class TableRendering extends React.Component{
	render () {
		return(
			 <Col md={ 12 } mdOffset={ 1 }>
					<BootstrapTable data={this.props.dataVal} striped hover condensed>
						<TableHeaderColumn dataField='id' isKey>ID</TableHeaderColumn>
						<TableHeaderColumn dataField='name'>NAME</TableHeaderColumn>
						<TableHeaderColumn dataField='gender'>GENDER</TableHeaderColumn>
					</BootstrapTable>
		     </Col>
			
		);
	}
}

export default TableRendering;

