import React from 'react';

class InputController extends React.Component{
     constructor(props) {
         super(props);
         this.state = {
           searchValue : ""
         }
         this.onChangeText = this.onChangeText.bind(this);
         this.onSearchSubmit=this.onSearchSubmit.bind(this);
    }
    onChangeText(e){
      this.setState({
         searchValue :e.target.value
      });
    }
    onSearchSubmit(){
      this.props.onSearch(this.state.searchValue);
    }

  render () { 
    return(
      <div className="searchText">
       Search Result : <input type="text" name="searchValue" value={this.state.searchValue} onChange={this.onChangeText}  />
      <button onClick={this.onSearchSubmit} className="primary"> Search Result </button>
      <br />
     </div>      
    );
  }
}

export default InputController;